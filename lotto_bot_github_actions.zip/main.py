import requests
import random
import json
from datetime import datetime
import os

def refresh_access_token():
    url = "https://kauth.kakao.com/oauth/token"
    data = {
        "grant_type": "refresh_token",
        "client_id": os.environ["KAKAO_REST_API_KEY"],
        "refresh_token": os.environ["KAKAO_REFRESH_TOKEN"],
        "client_secret": os.environ["KAKAO_CLIENT_SECRET"]
    }
    response = requests.post(url, data=data)
    response.raise_for_status()
    return response.json().get("access_token")

def generate_lotto_numbers():
    return sorted(random.sample(range(1, 46), 6))

lotto_sets = [generate_lotto_numbers() for _ in range(5)]

message = "[이번주 로또 추천 번호]\n\n"
for idx, numbers in enumerate(lotto_sets, start=1):
    message += f"{idx}세트: {numbers}\n"

access_token = refresh_access_token()
headers = {
    "Authorization": f"Bearer {access_token}"
}
template_object = {
    "object_type": "text",
    "text": message,
    "link": {
        "web_url": "https://www.dhlottery.co.kr",
        "mobile_web_url": "https://www.dhlottery.co.kr"
    },
    "button_title": "로또 확인하기"
}
data = {
    "template_object": json.dumps(template_object)
}
url = "https://kapi.kakao.com/v2/api/talk/memo/default/send"
response = requests.post(url, headers=headers, data=data)
now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
print(f"[{now}] 응답 코드: {response.status_code}, 결과: {response.text}")
